// View.cs
// Created by Holojam Inc. on 11.11.16

namespace Holojam.Network {

  /// <summary>
  /// Custom display class for Controllers and EventListeners/Pushers
  /// </summary>
  [System.Serializable]
  public sealed class View { }
}
